export const ar = {
  translation: {
    welcome: "مرحباً",
    description: "هذا مساعد ذكاء اصطناعي للتطوير والتسويق والطب العشبي",
    start: "ابدأ",
    generateWebsite: "إنشاء موقع",
    generateContent: "إنشاء محتوى",
    herbalist: "نصائح طب الأعشاب",
  }
};