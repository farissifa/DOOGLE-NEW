export const ru = {
  translation: {
    welcome: "Добро пожаловать",
    description: "Это ИИ-ассистент для разработки, маркетинга и траволечения",
    start: "Начать",
    generateWebsite: "Создать сайт",
    generateContent: "Создать контент",
    herbalist: "Советы травника",
  }
};